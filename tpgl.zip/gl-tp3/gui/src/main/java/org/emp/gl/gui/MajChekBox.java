package org.emp.gl.gui;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.messages.IMessage;
import org.emp.gl.messages.MAJ;

import javax.swing.*;

public class MajChekBox extends  IChekBocks{

    private javax.swing.JCheckBox maj = new javax.swing.JCheckBox("MAJ");

    public MajChekBox(JFrame frame,MessagingSenderGui messagingSenderGui)
    {
        super(messagingSenderGui);
        this.messaginSenderGui = messagingSenderGui;
        this.frame=frame;
        messaginSenderGui.attach(this);
        frame.add(maj);
        this.childes.add(this);
    }

    @Override
    public IMessage update(IMessage message) {
        return new MAJ(message);
    }

    public javax.swing.JCheckBox getChekBox(){
        return maj;
    }

}
