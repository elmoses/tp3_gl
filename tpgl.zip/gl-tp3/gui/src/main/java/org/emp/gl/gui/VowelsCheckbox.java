package org.emp.gl.gui;

import org.emp.gl.messages.IMessage;
import org.emp.gl.messages.RemovingVowels;
import org.emp.gl.messages.WhithoutWhiteSpace;

import javax.swing.*;

public class VowelsCheckbox extends IChekBocks{

    private javax.swing.JCheckBox vc = new javax.swing.JCheckBox("removing vowles");

    public VowelsCheckbox(JFrame frame, MessagingSenderGui messagingSenderGui)
    {
        super(messagingSenderGui);
        this.messaginSenderGui = messagingSenderGui;
        this.frame=frame;
        messaginSenderGui.attach(this);
        frame.add(vc);
        this.childes.add(this);
    }

    @Override
    public IMessage update(IMessage message) {
        return new RemovingVowels(message);
    }

    public javax.swing.JCheckBox getChekBox(){
        return vc;
    }

}
