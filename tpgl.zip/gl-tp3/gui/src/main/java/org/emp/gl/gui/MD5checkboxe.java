package org.emp.gl.gui;

import org.emp.gl.messages.IMessage;
import org.emp.gl.messages.MD5;
import org.emp.gl.messages.SHA1;

import javax.swing.*;

public class MD5checkboxe extends IChekBocks{
    private javax.swing.JCheckBox vc = new javax.swing.JCheckBox("MD5");

    public MD5checkboxe(JFrame frame, MessagingSenderGui messagingSenderGui)
    {
        super(messagingSenderGui);
        this.messaginSenderGui = messagingSenderGui;
        this.frame=frame;
        messaginSenderGui.attach(this);
        frame.add(vc);
        this.childes.add(this);
    }

    @Override
    public IMessage update(IMessage message) {
        return new MD5(message);
    }

    public javax.swing.JCheckBox getChekBox(){
        return vc;
    }

}
