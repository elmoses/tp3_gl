package org.emp.gl.gui;

import org.emp.gl.messages.IMessage;

import javax.swing.*;
import java.awt.*;
import java.io.FileReader;
import java.util.ArrayList;

public abstract class IChekBocks {
    MessagingSenderGui messaginSenderGui;

    ArrayList<IChekBocks> childes;
    public abstract IMessage update(IMessage message);
    public abstract JCheckBox getChekBox();
    public  ArrayList<IChekBocks> getList() { return childes;}
    JFrame frame;
    IChekBocks(MessagingSenderGui messaginSenderGui)
    {
        childes = new ArrayList<>();
        this.messaginSenderGui=messaginSenderGui;
    }

}
