package org.emp.gl.gui;

import org.emp.gl.messages.IMessage;
import org.emp.gl.messages.SHA1;
import org.emp.gl.messages.Vigenere;

import javax.swing.*;

public class SHA1Chekbox extends IChekBocks{
    private javax.swing.JCheckBox vc = new javax.swing.JCheckBox("SHA1");

    public SHA1Chekbox(JFrame frame, MessagingSenderGui messagingSenderGui)
    {
        super(messagingSenderGui);
        this.messaginSenderGui = messagingSenderGui;
        this.frame=frame;
        messaginSenderGui.attach(this);
        frame.add(vc);
        this.childes.add(this);
    }

    @Override
    public IMessage update(IMessage message) {
        return new SHA1(message);
    }

    public javax.swing.JCheckBox getChekBox(){
        return vc;
    }

}
