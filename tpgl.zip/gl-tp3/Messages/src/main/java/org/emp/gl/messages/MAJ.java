/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.messages;

import java.util.Locale;

/**
 *
 * @author walid
 */
public class MAJ extends SimpleAlgorithmes {

    public MAJ(IMessage m) {
        super(m);
    }

    @Override
    public void setMessage(String message) {
        super.setMessage(message.toUpperCase(Locale.ROOT));
        System.out.println("im upper case");
    }

}
