package org.emp.gl.messages;

public class WhithoutWhiteSpace extends SimpleAlgorithmes{


    public WhithoutWhiteSpace(IMessage m) {
        super(m);
    }

    @Override
    public void setMessage(String message) {
        super.setMessage(message.replaceAll("\\s+",""));
        System.out.println("im whithou spaces");
    }
}
