/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.messages;

/**
 *
 * @author walid
 */


public abstract class Decorator implements IMessage{
    
    
    IMessage message;

    private Decorator(){};
    public Decorator(IMessage m ) {
        this.message = m ;
    }


    @Override
    public String getTitle() {
    return  this.message.getTitle();
    }

    @Override
    public String getSender() {
    return this.message.getSender();
    }

    @Override
    public String getMessage() {
    return this.message.getMessage();
    }

    @Override
    public void setTitle(String title) {
    this.message.setTitle(title);
    }

    @Override
    public void setSender(String sender) {
    this.message.setSender(sender);
    }

    @Override
    public void setMessage(String message) {
     this.message.setMessage(message);

    }

    public String toString(){
       return  message.toString();
    }

}
