package org.emp.gl.messages;

public abstract class ConfidentialtéAlgorithmes extends Decorator{

    public ConfidentialtéAlgorithmes(IMessage m) {
        super(m);
    }
}
