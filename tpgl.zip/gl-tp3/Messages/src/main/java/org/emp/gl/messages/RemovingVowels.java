package org.emp.gl.messages;

import java.util.Locale;

public class RemovingVowels extends SimpleAlgorithmes{
    public RemovingVowels(IMessage m) {
        super(m);
    }
    @Override
    public void setMessage(String message)
    {
        super.setMessage(message.replaceAll("[aeiou]", "").replaceAll("[AEIOU]",""));
    }
}
