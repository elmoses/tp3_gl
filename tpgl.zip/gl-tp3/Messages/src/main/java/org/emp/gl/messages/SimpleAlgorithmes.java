package org.emp.gl.messages;

public class SimpleAlgorithmes extends Decorator{
    public SimpleAlgorithmes(IMessage m) {
        super(m);
    }
}
