package org.emp.gl.messages;

import java.util.Locale;

public class Vigenere extends ConfidentialtéAlgorithmes{
    public Vigenere(IMessage m) {
        super(m);
    }

    static String generateKey(String str, String key)
    {
        int x = str.length();

        for (int i = 0; ; i++)
        {
            if (x == i)
                i = 0;
            if (key.length() == str.length())
                break;
            key+=(key.charAt(i));
        }
        return key;
    }

    static String cipherText(String str, String key)
    {
        String cipher_text="";

        for (int i = 0; i < str.length(); i++)
        {
            int x = (str.charAt(i) + key.charAt(i)) %26;
            x += 'A';

            cipher_text+=(char)(x);
        }
        return cipher_text;
    }

    static String originalText(String cipher_text, String key)
    {
        String orig_text="";

        for (int i = 0 ; i < cipher_text.length() &&
                i < key.length(); i++)
        {
            int x = (cipher_text.charAt(i) -
                    key.charAt(i) + 26) %26;
            x += 'A';
            orig_text+=(char)(x);
        }
        return orig_text;
    }


    @Override
    public void setMessage(String message) {
        String keyword = "AYUSH";
        message = message.toUpperCase(Locale.ROOT);
        keyword = keyword.toUpperCase(Locale.ROOT);
        String key = generateKey(message, keyword);
        String cipher_text = cipherText(message, key);
        super.setMessage(cipher_text);
        System.out.println(originalText(cipher_text,key));
    }
}
