package org.emp.gl.messages;

public abstract class IntegrityAlgorithmes extends Decorator{
    public IntegrityAlgorithmes(IMessage m) {
        super(m);
    }
}
