# gl-tp3
Exercice sur les décorateurs ! 
